import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 * CASE2 : REST API ȣ������ �±׺��� �����Ͽ� ����ϴ� ����  
 */
public class REST_API2 {

	public static void main(String[] args) throws SAXException, IOException {
		// TODO Auto-generated method stub
		
		URL url = null;
		URLConnection conn = null;
		
		String url1 = "http://plus.kipris.or.kr" +
				  "/kipo-api/kipi/patUtiModInfoSearchSevice/getBibliographySumryInfoSearch";

		String applno = "1020050050026";
		String key = "";	/** AccessKey �Ǵ� ServiceKey �Է� �ʿ� **/

		String url2 = "?applicationNumber=" + applno;
		String url3 = "&ServiceKey="+key;
		
		InputStream is;
		
		try {
			url = new URL(url1+url2+url3);
			conn = url.openConnection();
			is = conn.getInputStream();
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder docb;
			
			docb = dbf.newDocumentBuilder();
			Document doc = docb.parse(url1+url2+url3);
			doc.getDocumentElement().normalize();
			
			NodeList nList = doc.getElementsByTagName("item");
			
			for(int idx=0; idx<nList.getLength();++idx) {
				
				Node n= nList.item(idx);
				
				/*
				 * ��� �±������� KIPRISPlus �������� > �����͸�� > ���������� > API > ��ȸ�ϰ����ϴ� ��ǰ���� �� ��°�(Response Parameter) �Ǵ� REST_API.java ȣ�� ��� ����
				 *  KIPRISPlus �� �������� ����Ǿ��ִ� ��°��� ��� �߸� ����� ��찡 ������ �� �����Ƿ�
				 *  �����׽�Ʈ ��� �Ǵ� REST_API.java ȣ���� ���� Ȯ�ε� �±������� Ȱ���Ͻô� ���� ��õ�帳�ϴ�.
				 *  �� ������ �� ��°��� �߸� ����� ������ �������ֽø� �����ؼ� �ݿ��ϵ��� �ϰڽ��ϴ�.
				 */
				
				// �������				
				String applicationDate = "";
				try{
					if(((Element)n).getElementsByTagName("applicationDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("applicationDate").item(0).getTextContent()))
						applicationDate = "";
					else
						applicationDate = ((Element)n).getElementsByTagName("applicationDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �������				
				String applicationFlag = "";
				try{
					if(((Element)n).getElementsByTagName("applicationFlag").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("applicationFlag").item(0).getTextContent()))
						applicationFlag = "";
					else
						applicationFlag = ((Element)n).getElementsByTagName("applicationFlag").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �����ȣ				
				String applicationNumber = "";
				try{
					if(((Element)n).getElementsByTagName("applicationNumber").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("applicationNumber").item(0).getTextContent()))
						applicationNumber = "";
					else
						applicationNumber = ((Element)n).getElementsByTagName("applicationNumber").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// û���׼�				
				String claimCount = "";
				try{
					if(((Element)n).getElementsByTagName("claimCount").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("claimCount").item(0).getTextContent()))
						claimCount = "";
					else
						claimCount = ((Element)n).getElementsByTagName("claimCount").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ����ó�г���				
				String finalDisposal = "";
				try{
					if(((Element)n).getElementsByTagName("finalDisposal").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("finalDisposal").item(0).getTextContent()))
						finalDisposal = "";
					else
						finalDisposal = ((Element)n).getElementsByTagName("finalDisposal").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �߸��Ǹ�Ī(����)				
				String inventionTitle = "";
				try{
					if(((Element)n).getElementsByTagName("inventionTitle").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("inventionTitle").item(0).getTextContent()))
						inventionTitle = "";
					else
						inventionTitle = ((Element)n).getElementsByTagName("inventionTitle").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �߸��Ǹ�Ī(����)				
				String inventionTitleEng = "";
				try{
					if(((Element)n).getElementsByTagName("inventionTitleEng").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("inventionTitleEng").item(0).getTextContent()))
						inventionTitleEng = "";
					else
						inventionTitleEng = ((Element)n).getElementsByTagName("inventionTitleEng").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ��������				
				String openDate = "";
				try{
					if(((Element)n).getElementsByTagName("openDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("openDate").item(0).getTextContent()))
						openDate = "";
					else
						openDate = ((Element)n).getElementsByTagName("openDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ������ȣ				
				String openNumber = "";
				try{
					if(((Element)n).getElementsByTagName("openNumber").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("openNumber").item(0).getTextContent()))
						openNumber = "";
					else
						openNumber = ((Element)n).getElementsByTagName("openNumber").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ������������				
				String originalApplicationDate = "";
				try{
					if(((Element)n).getElementsByTagName("originalApplicationDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("originalApplicationDate").item(0).getTextContent()))
						originalApplicationDate = "";
					else
						originalApplicationDate = ((Element)n).getElementsByTagName("originalApplicationDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ���������				
				String originalApplicationKind = "";
				try{
					if(((Element)n).getElementsByTagName("originalApplicationKind").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("originalApplicationKind").item(0).getTextContent()))
						originalApplicationKind = "";
					else
						originalApplicationKind = ((Element)n).getElementsByTagName("originalApplicationKind").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ����������ȣ				
				String originalApplicationNumber = "";
				try{
					if(((Element)n).getElementsByTagName("originalApplicationNumber").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("originalApplicationNumber").item(0).getTextContent()))
						originalApplicationNumber = "";
					else
						originalApplicationNumber = ((Element)n).getElementsByTagName("originalApplicationNumber").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �ɻ�û������				
				String originalExaminationRequestDate = "";
				try{
					if(((Element)n).getElementsByTagName("originalExaminationRequestDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("originalExaminationRequestDate").item(0).getTextContent()))
						originalExaminationRequestDate = "";
					else
						originalExaminationRequestDate = ((Element)n).getElementsByTagName("originalExaminationRequestDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �ɻ�û������				
				String originalExaminationRequestFlag = "";
				try{
					if(((Element)n).getElementsByTagName("originalExaminationRequestFlag").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("originalExaminationRequestFlag").item(0).getTextContent()))
						originalExaminationRequestFlag = "";
					else
						originalExaminationRequestFlag = ((Element)n).getElementsByTagName("originalExaminationRequestFlag").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ��������				
				String publicationDate = "";
				try{
					if(((Element)n).getElementsByTagName("publicationDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("publicationDate").item(0).getTextContent()))
						publicationDate = "";
					else
						publicationDate = ((Element)n).getElementsByTagName("publicationDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ������ȣ				
				String publicationNumber = "";
				try{
					if(((Element)n).getElementsByTagName("publicationNumber").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("publicationNumber").item(0).getTextContent()))
						publicationNumber = "";
					else
						publicationNumber = ((Element)n).getElementsByTagName("publicationNumber").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// �������				
				String registerDate = "";
				try{
					if(((Element)n).getElementsByTagName("registerDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("registerDate").item(0).getTextContent()))
						registerDate = "";
					else
						registerDate = ((Element)n).getElementsByTagName("registerDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ��Ϲ�ȣ				
				String registerNumber = "";
				try{
					if(((Element)n).getElementsByTagName("registerNumber").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("registerNumber").item(0).getTextContent()))
						registerNumber = "";
					else
						registerNumber = ((Element)n).getElementsByTagName("registerNumber").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ��ϻ���				
				String registerStatus = "";
				try{
					if(((Element)n).getElementsByTagName("registerStatus").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("registerStatus").item(0).getTextContent()))
						registerStatus = "";
					else
						registerStatus = ((Element)n).getElementsByTagName("registerStatus").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				// ��������������				
				String translationSubmitDate = "";
				try{
					if(((Element)n).getElementsByTagName("translationSubmitDate").item(0).getTextContent() == null || "".equals(((Element)n).getElementsByTagName("translationSubmitDate").item(0).getTextContent()))
						translationSubmitDate = "";
					else
						translationSubmitDate = ((Element)n).getElementsByTagName("translationSubmitDate").item(0).getTextContent();
				}catch(Exception E) {
					E.getLocalizedMessage();
				}
				
				System.out.println("## Case 2");
				System.out.println("������� : " + applicationDate);
				System.out.println("������� : " + applicationFlag);
				System.out.println("�����ȣ : " + applicationNumber);
				System.out.println("û���׼� : " + claimCount);
				System.out.println("����ó�г��� : " + finalDisposal);
				System.out.println("�߸��Ǹ�Ī(����) : " + inventionTitle);
				System.out.println("�߸��Ǹ�Ī(����) : " + inventionTitleEng);
				System.out.println("�������� : " + openDate);
				System.out.println("������ȣ : " + openNumber);
				System.out.println("������������ : " + originalApplicationDate);
				System.out.println("��������� : " + originalApplicationKind);
				System.out.println("����������ȣ : " + originalApplicationNumber);
				System.out.println("�ɻ�û������ : " + originalExaminationRequestDate);
				System.out.println("�ɻ�û������ : " + originalExaminationRequestFlag);
				System.out.println("�������� : " + publicationDate);
				System.out.println("������ȣ : " + publicationNumber);
				System.out.println("������� : " + registerDate);
				System.out.println("��Ϲ�ȣ : " + registerNumber);
				System.out.println("��ϻ��� : " + registerStatus);
				System.out.println("�������������� : " + translationSubmitDate);
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}