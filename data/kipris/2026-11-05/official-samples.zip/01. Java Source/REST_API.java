import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.xml.sax.SAXException;

/*
 * CASE1 : REST API ȣ������ XML ������ ����ϴ� ����  
 */
public class REST_API {

	public static void main(String[] args) throws SAXException, IOException {
		// TODO Auto-generated method stub

		URL url = null;
		URLConnection conn = null;
		
		//url ����(�Է°�, KEY�� ����)
		String url1 = "http://plus.kipris.or.kr" +
					  "/kipo-api/kipi/patUtiModInfoSearchSevice/getBibliographySumryInfoSearch";

		String applno = "1020050050026";
		String key = "";	/** AccessKey �Ǵ� ServiceKey �Է� �ʿ� **/

		String url2 = "?applicationNumber=" + applno;
		String url3 = "&ServiceKey="+key;
		
		try {
			
			InputStream is;
			
			url = new URL(url1+url2+url3);
			conn = url.openConnection();
			is = conn.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			
            System.out.println("## Case 1");
            String xml = null;
            while((xml = br.readLine()) != null) {
        		System.out.println(xml.replace("><", ">\n<"));
            }
            br.close();
            
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}